from googlesearch import search
while True:
 data = input("Enter your Search:")
 co = int(input("Enter Search Counts:"))
 if co > 1:
  print(co,"results related to",data,"are:")
 else:
  print(co,"result related to",data,"is:")
 print()
 for i in search(data,co,advanced=True):
  print(i.url)
  print(i.title)
  print(i.description)
  print()
  print()