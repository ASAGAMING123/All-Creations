from googlesearch import search
while True:
 data = input("Enter your Search:")
 print()
 for i in search(data,20,advanced=True):
  print(i.url)
  print(i.title)
  print(i.description)
  print()
  print()